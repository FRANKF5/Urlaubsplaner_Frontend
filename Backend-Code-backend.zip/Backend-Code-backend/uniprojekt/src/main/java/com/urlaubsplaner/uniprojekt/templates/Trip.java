package com.urlaubsplaner.uniprojekt.templates;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public class Trip {
    private Long id;
    private String destination;
    private Long ownerAuthId;
    private Integer budget;
    private Date startDate;
    private Date endDate;
    private Timestamp createdAt;
    private Integer maxBudget;
    private List<Activity> activities;

    // Constructors
    public Trip() {
    }

    public Trip(Long id, String destination, Long ownerAuthId, Integer budget, Date startDate, Date endDate, Timestamp createdAt, Integer maxBudget, List<Activity> activities) {
        this.id = id;
        this.destination = destination;
        this.ownerAuthId = ownerAuthId;
        this.budget = budget;
        this.startDate = startDate;
        this.endDate = endDate;
        this.createdAt = createdAt;
        this.maxBudget = maxBudget;
        this.activities = activities;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Long getOwnerAuthId() {
        return ownerAuthId;
    }

    public void setOwnerAuthId(Long ownerAuthId) {
        this.ownerAuthId = ownerAuthId;
    }

    public Integer getBudget() {
        return budget;
    }

    public void setBudget(Integer budget) {
        this.budget = budget;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getMaxBudget() {
        return maxBudget;
    }

    public void setMaxBudget(Integer maxBudget) {
        this.maxBudget = maxBudget;
    }

    public List<Activity> getActivities() {
        return activities;
    }

    public void setActivities(List<Activity> activities) {
        this.activities = activities;
    }
}
