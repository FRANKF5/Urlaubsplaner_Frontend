package com.urlaubsplaner.uniprojekt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrlaubsplanerApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrlaubsplanerApplication.class, args);
	}

}
