package com.urlaubsplaner.uniprojekt.templates;

public class RemoveUserRequest {
    private Long tripId;
    private String email;

    public RemoveUserRequest() {
    }

    public RemoveUserRequest(Long tripId, String email) {
        this.tripId = tripId;
        this.email = email;
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
