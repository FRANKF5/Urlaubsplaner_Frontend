package com.urlaubsplaner.uniprojekt.bl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.urlaubsplaner.uniprojekt.database.TripConnector;
import com.urlaubsplaner.uniprojekt.database.AuthConnector;
import com.urlaubsplaner.uniprojekt.templates.Trip;
import com.urlaubsplaner.uniprojekt.templates.Activity;
import com.urlaubsplaner.uniprojekt.templates.TripMember;

@Service
public class TripService {

    private final TripConnector tripConnector;
    private final AuthConnector authConnector;

    public TripService(TripConnector tripConnector, AuthConnector authConnector) {
        this.tripConnector = tripConnector;
        this.authConnector = authConnector;
    }

    // Get all trips (owned + shared) for a user
    public List<Trip> getAllTrips(long authId) {
        if (authId <= 0) {
            return null;
        }
        List<Trip> ownedTrips = tripConnector.getOwnedTrips(authId);
        List<Trip> sharedTrips = tripConnector.getSharedTrips(authId);
        ownedTrips.addAll(sharedTrips);
        return ownedTrips;
    }

    // Get only owned trips
    public List<Trip> getOwnedTrips(long authId) {
        if (authId <= 0) {
            return null;
        }
        return tripConnector.getOwnedTrips(authId);
    }

    // Get only shared trips
    public List<Trip> getSharedTrips(long authId) {
        if (authId <= 0) {
            return null;
        }
        return tripConnector.getSharedTrips(authId);
    }

    // Create a new trip
    public Long createTrip(Trip trip, long authId) {
        if (trip == null || authId <= 0) {
            return null;
        }
        trip.setOwnerAuthId(authId);
        return tripConnector.createTrip(trip);
    }

    // Update a trip (only owner can update)
    public boolean updateTrip(Trip trip, long authId) {
        if (trip == null || trip.getId() == null || authId <= 0) {
            return false;
        }
        // Check if user has write permission
        if (!tripConnector.isTripWritableBy(trip.getId(), authId)) {
            return false;
        }
        return tripConnector.updateTrip(trip, authId);
    }

    // Check if user can read a trip
    public boolean canReadTrip(long tripId, long authId) {
        if (tripId <= 0 || authId <= 0) {
            return false;
        }
        return tripConnector.isTripReadableBy(tripId, authId);
    }

    // Check if user can write to a trip
    public boolean canWriteTrip(long tripId, long authId) {
        if (tripId <= 0 || authId <= 0) {
            return false;
        }
        return tripConnector.isTripWritableBy(tripId, authId);
    }

    // Activity management methods
    public List<Activity> getTripActivities(long tripId, long authId) {
        if (authId <= 0 || tripId <= 0 || !tripConnector.isTripReadableBy(tripId, authId)) {
            return null;
        }
        return tripConnector.getActivitiesForTrip(tripId);
    }

    public long addActivityToTrip(long tripId, Activity activity, long authId) {
        if (authId <= 0 || tripId <= 0 || activity == null || !tripConnector.isTripWritableBy(tripId, authId)) {
            return -1L;
        }
        return tripConnector.createActivity(tripId, activity);
    }

    public boolean updateActivityInTrip(long tripId, Activity activity, long authId) {
        if (authId <= 0 || tripId <= 0 || activity == null || !tripConnector.isTripWritableBy(tripId, authId)) {
            return false;
        }
        return tripConnector.updateActivity(tripId, activity);
    }

    public boolean deleteActivityFromTrip(Trip trip, long activityId, long authId) {
        if (authId <= 0 || trip == null || activityId <= 0 || trip.getOwnerAuthId() != authId) {
            return false;
        }
        return tripConnector.deleteActivity(activityId);
    }

    // --- GROUP MANAGEMENT METHODS ---

    public boolean addUserToTrip(long tripId, String email, long authId) {
        if (tripId <= 0 || email == null || email.isEmpty() || authId <= 0) {
            return false;
        }

        // Check if the requesting user has write permission
        if (!canWriteTrip(tripId, authId)) {
            return false;
        }

        // Get the authId of the user to add
        Long authIdToAdd = authConnector.getAuthIdByEmail(email);
        if (authIdToAdd == null || authIdToAdd <= 0) {
            return false; // User with this email does not exist
        }

        // Cannot add the trip owner again
        if (tripConnector.isTripOwner(tripId, authIdToAdd)) {
            return false;
        }

        // Add user with 'viewer' role by default
        return tripConnector.addUserToTrip(tripId, authIdToAdd, "viewer");
    }

   
    public boolean removeUserFromTrip(long tripId, String email, long authId) {
        if (tripId <= 0 || email == null || email.isEmpty() || authId <= 0) {
            return false;
        }

        // Check if the requesting user has write permission
        if (!canWriteTrip(tripId, authId)) {
            return false;
        }

        // Get the authId of the user to remove
        Long authIdToRemove = authConnector.getAuthIdByEmail(email);
        if (authIdToRemove == null || authIdToRemove <= 0) {
            return false; // User with this email does not exist
        }

        // Cannot remove the trip owner
        if (tripConnector.isTripOwner(tripId, authIdToRemove)) {
            return false;
        }

        return tripConnector.removeUserFromTrip(tripId, authIdToRemove);
    }

   
    public boolean leaveTrip(long tripId, long authId) {
        if (tripId <= 0 || authId <= 0) {
            return false;
        }

        // Check if user is a member of the trip (can read it)
        if (!canReadTrip(tripId, authId)) {
            return false;
        }

        // Cannot leave if user is the trip owner
        if (tripConnector.isTripOwner(tripId, authId)) {
            return false;
        }

        return tripConnector.removeUserFromTrip(tripId, authId);
    }

    
    public List<TripMember> getTripMembers(long tripId) {
        if (tripId <= 0) {
            return null;
        }
        return tripConnector.getTripMembers(tripId);
    }
}
