package com.urlaubsplaner.uniprojekt.api;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.urlaubsplaner.uniprojekt.bl.BadRequestException;
import com.urlaubsplaner.uniprojekt.bl.TripService;
import com.urlaubsplaner.uniprojekt.templates.AddUserRequest;
import com.urlaubsplaner.uniprojekt.templates.LeaveGroupRequest;
import com.urlaubsplaner.uniprojekt.templates.RemoveUserRequest;
import com.urlaubsplaner.uniprojekt.templates.TripMember;

@RestController
@RequestMapping("/api/groups")
public class GroupApi {

    private final TripService tripService;

    public GroupApi(TripService tripService) {
        this.tripService = tripService;
    }

    @PostMapping("/user")
    public ResponseEntity<Boolean> addUserToTrip(
            @RequestBody AddUserRequest request,
            @AuthenticationPrincipal long authId) throws BadRequestException {
        
        if (request.getTripId() == null || request.getTripId() <= 0) {
            throw new BadRequestException("Gültige trip_id ist erforderlich");
        }
        
        if (request.getEmail() == null || request.getEmail().isEmpty()) {
            throw new BadRequestException("E-Mail ist erforderlich");
        }
        
        boolean added = tripService.addUserToTrip(request.getTripId(), request.getEmail(), authId);
        
        if (!added) {
            throw new BadRequestException("Nutzer konnte nicht zur Reise hinzugefügt werden. Nutzer existiert möglicherweise nicht, ist bereits Mitglied oder Sie haben keine Berechtigung.");
        }
        
        return ResponseEntity.status(HttpStatus.CREATED).body(true);
    }

    @DeleteMapping("/user")
    public ResponseEntity<Boolean> removeUserFromTrip(
            @RequestBody RemoveUserRequest request,
            @AuthenticationPrincipal long authId) throws BadRequestException {
        
        if (request.getTripId() == null || request.getTripId() <= 0) {
            throw new BadRequestException("Gültige trip_id ist erforderlich");
        }
        
        if (request.getEmail() == null || request.getEmail().isEmpty()) {
            throw new BadRequestException("E-Mail ist erforderlich");
        }
        
        boolean removed = tripService.removeUserFromTrip(request.getTripId(), request.getEmail(), authId);
        
        if (!removed) {
            throw new BadRequestException("Nutzer konnte nicht von der Reise entfernt werden. Nutzer existiert möglicherweise nicht, ist der Besitzer oder Sie haben keine Berechtigung.");
        }
        
        return ResponseEntity.ok(true);
    }

    @PostMapping("/leave")
    public ResponseEntity<Boolean> leaveTrip(
            @RequestBody LeaveGroupRequest request,
            @AuthenticationPrincipal long authId) throws BadRequestException {
        
        if (request.getTripId() == null || request.getTripId() <= 0) {
            throw new BadRequestException("Gültige trip_id ist erforderlich");
        }
        
        boolean left = tripService.leaveTrip(request.getTripId(), authId);
        
        if (!left) {
            throw new BadRequestException("Reise konnte nicht verlassen werden. Sie sind möglicherweise der Besitzer oder kein Mitglied.");
        }
        
        return ResponseEntity.ok(true);
    }

    @GetMapping("/group")
    public ResponseEntity<List<TripMember>> getTripMembers(
            @RequestParam("trip_id") Long tripId,
            @AuthenticationPrincipal long authId) throws BadRequestException {
        
        if (tripId == null || tripId <= 0) {
            throw new BadRequestException("Gültige trip_id ist erforderlich");
        }
        
        if (!tripService.canReadTrip(tripId, authId)) {
            throw new BadRequestException("Sie haben keine Berechtigung, die Mitglieder dieser Reise anzuzeigen");
        }
        
        List<TripMember> members = tripService.getTripMembers(tripId);
        
        if (members == null) {
            throw new BadRequestException("Reisemitglieder konnten nicht abgerufen werden");
        }
        
        return ResponseEntity.ok(members);
    }
}
