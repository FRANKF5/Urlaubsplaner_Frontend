package com.urlaubsplaner.uniprojekt.api;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.urlaubsplaner.uniprojekt.bl.BadRequestException;
import com.urlaubsplaner.uniprojekt.bl.TripService;
import com.urlaubsplaner.uniprojekt.templates.Trip;

@RestController
@RequestMapping("/api/trips")
public class TripApi {

    private final TripService tripService;

    public TripApi(TripService tripService) {
        this.tripService = tripService;
    }

    @GetMapping
    public ResponseEntity<List<Trip>> getAllTrips(@AuthenticationPrincipal long authId) throws BadRequestException {
        List<Trip> trips = tripService.getAllTrips(authId);
        if (trips == null) {
            throw new BadRequestException("Failed to retrieve trips");
        }
        return ResponseEntity.ok(trips);
    }

    @GetMapping("/owned")
    public ResponseEntity<List<Trip>> getOwnedTrips(@AuthenticationPrincipal long authId) throws BadRequestException {
        List<Trip> trips = tripService.getOwnedTrips(authId);
        if (trips == null) {
            throw new BadRequestException("Failed to retrieve owned trips");
        }
        return ResponseEntity.ok(trips);
    }

    @GetMapping("/shared")
    public ResponseEntity<List<Trip>> getSharedTrips(@AuthenticationPrincipal long authId) throws BadRequestException {
        List<Trip> trips = tripService.getSharedTrips(authId);
        if (trips == null) {
            throw new BadRequestException("Failed to retrieve shared trips");
        }
        return ResponseEntity.ok(trips);
    }

    @PostMapping
    public ResponseEntity<Long> createTrip(@RequestBody Trip trip, @AuthenticationPrincipal long authId) throws BadRequestException {
        if (trip.getDestination() == null || trip.getDestination().isEmpty()) {
            throw new BadRequestException("Destination is required");
        }
        Long tripId = tripService.createTrip(trip, authId);
        if (tripId == null) {
            throw new BadRequestException("Failed to create trip");
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(tripId);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Boolean> updateTrip(@PathVariable long id, @RequestBody Trip trip, @AuthenticationPrincipal long authId) throws BadRequestException {
        trip.setId(id);
        
        // Check if user can write to this trip
        if (!tripService.canWriteTrip(id, authId)) {
            throw new BadRequestException("You don't have permission to update this trip");
        }
        
        boolean updated = tripService.updateTrip(trip, authId);
        if (!updated) {
            throw new BadRequestException("Failed to update trip");
        }
        return ResponseEntity.ok(true);
    }

    @PatchMapping("/{id}/budget")
    public ResponseEntity<Boolean> updateTripBudget(@PathVariable long id, @RequestBody Trip trip, @AuthenticationPrincipal long authId) throws BadRequestException {
        trip.setId(id);
        
        // Check if user can write to this trip
        if (!tripService.canWriteTrip(id, authId)) {
            throw new BadRequestException("You don't have permission to update this trip's budget");
        }
        
        if (trip.getBudget() == null && trip.getMaxBudget() == null) {
            throw new BadRequestException("Budget or maxBudget is required");
        }
        
        boolean updated = tripService.updateTrip(trip, authId);
        if (!updated) {
            throw new BadRequestException("Failed to update trip budget");
        }
        return ResponseEntity.ok(true);
    }
}
