package com.urlaubsplaner.uniprojekt.templates;

public class LeaveGroupRequest {
    private Long tripId;

    public LeaveGroupRequest() {
    }

    public LeaveGroupRequest(Long tripId) {
        this.tripId = tripId;
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }
}
