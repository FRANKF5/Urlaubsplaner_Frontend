package com.urlaubsplaner.uniprojekt.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.urlaubsplaner.uniprojekt.bl.BadRequestException;
import com.urlaubsplaner.uniprojekt.bl.UserSettingService;
import com.urlaubsplaner.uniprojekt.templates.UserConfig;

@RestController
@RequestMapping("/api/settings")
public class SettingsApi {

    private final UserSettingService userSettingService;

    public SettingsApi(UserSettingService userSettingService) {
        this.userSettingService = userSettingService;
    }

    @GetMapping
    public ResponseEntity<List<UserConfig>> getAllSettings(@AuthenticationPrincipal long authId) throws BadRequestException {
        List<UserConfig> settings = userSettingService.getUserSettings(authId);
        if (settings == null) {
            throw new BadRequestException("Failed to retrieve settings");
        }
        return ResponseEntity.ok(settings);
    }

    @GetMapping("/{option}")
    public ResponseEntity<UserConfig> getSetting(@PathVariable String option, @AuthenticationPrincipal long authId) throws BadRequestException {
        if (option == null || option.isEmpty()) {
            throw new BadRequestException("Option parameter is required");
        }
        
        UserConfig setting = userSettingService.getUserSetting(authId, option);
        if (setting == null) {
            throw new BadRequestException("Setting not found");
        }
        return ResponseEntity.ok(setting);
    }

    @PatchMapping("/{option}")
    public ResponseEntity<Boolean> updateSetting(@PathVariable String option, @RequestBody UserConfig config, @AuthenticationPrincipal long authId) throws BadRequestException {
        if (option == null || option.isEmpty()) {
            throw new BadRequestException("Option parameter is required");
        }
        
        if (config.getValue() == null || config.getValue().isEmpty()) {
            throw new BadRequestException("Value is required");
        }
        
        boolean updated = userSettingService.upsertUserSetting(authId, option, config.getValue());
        if (!updated) {
            throw new BadRequestException("Failed to update setting");
        }
        return ResponseEntity.ok(true);
    }
}
