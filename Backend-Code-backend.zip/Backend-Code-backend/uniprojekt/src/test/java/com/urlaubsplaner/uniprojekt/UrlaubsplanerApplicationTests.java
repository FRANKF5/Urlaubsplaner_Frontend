package com.urlaubsplaner.uniprojekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlaubsplanerApplicationTests {

	@Test
	void contextLoads() {
	}

}
